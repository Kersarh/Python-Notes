print('demo/__main__.py executed')
from __init__ import main
main()