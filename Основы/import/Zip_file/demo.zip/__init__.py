print('demo/__init__.py executed')
def main():
    print('main executed')