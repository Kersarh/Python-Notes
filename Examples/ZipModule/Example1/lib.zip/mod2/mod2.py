import sys


def print_sysinfo():
    print(80 * "-")
    print(sys.version)
    print(80 * "-")


def print_notInit():
    print("not init")
