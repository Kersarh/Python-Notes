from .mod2 import print_sysinfo
